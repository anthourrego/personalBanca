import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'cs.prosof.TemparioApp',
  appName: 'TemparioApp',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
