export const environment = {
  production: true,
  //urlBack: 'http://192.168.0.224:8016/dev/TemparioApp/TemparioBack/',
	urlBack: 'https://cs.prosof.co:8011/TempariosAPP/TemparioBack/',
	//urlBack: 'https://prosof.co:8011/testing/TemparioBack/',
  nit: '900445834'
  //nit: '900445834_1'
};
