import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './header/header.component';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { FooterVersionComponent } from './footer-version/footer-version.component';
import { AppVersion } from '@awesome-cordova-plugins/app-version/ngx';



@NgModule({
	declarations: [HeaderComponent, FooterVersionComponent],
	imports: [
		IonicModule,
		CommonModule,
		FormsModule
	],
	exports: [HeaderComponent, FooterVersionComponent],
	providers: [AppVersion]
})
export class ComponentesModule { }
