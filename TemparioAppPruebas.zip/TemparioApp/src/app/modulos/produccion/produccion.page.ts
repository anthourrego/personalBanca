import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'app-produccion',
	templateUrl: './produccion.page.html',
	styleUrls: ['./produccion.page.scss'],
})
export class ProduccionPage implements OnInit {

	constructor() { }

	ngOnInit() {
	}

}
