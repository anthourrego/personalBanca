import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'app-modulos',
	templateUrl: './modulos.component.html',
	styleUrls: ['./modulos.component.scss'],
})
export class ModulosComponent implements OnInit {

	constructor() { }

	ngOnInit() { }

}
